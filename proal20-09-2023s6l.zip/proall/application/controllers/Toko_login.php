<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Toko_login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}
	public function index()
	{
		$this->form_validation->set_rules('username','Username','trim|required',[
			'required' => 'tidak ditemukan!'
		]);
		$this->form_validation->set_rules('sandi','Sandi','trim|required',[
			'required' => 'sandi salah!'
		]);
		if($this->form_validation->run()== false){


			$data['title'] = 'login';
			$this->load->view('templates/auth_header',$data);
			$this->load->view('toko/login-toko');
			$this->load->view('templates/auth_footer');
		} else {
			// $this->_login(); untuk menambah kan function 
			$this->_login();
		}
	}


	private function _login()
	{
		$username =$this->input->post('username');
		$sandi =$this->input->post('sandi');



		$pengguna_toko = $this->db->get_where('pengguna_toko',['username'=> $username])->row_array();
		
		// jika penggunanya ada
		if($pengguna_toko) {
			// jika penggunanya aktif
			if ($pengguna_toko['aktivasi']==1){
				// cek sandi
				if(password_verify($sandi, $pengguna_toko['sandi'])) {
					$data = [
						'username' =>$pengguna_toko['username'],
						'role_id' => $pengguna_toko['role_id']
					];

					// set_userdata untuk menyimpan data email+role_id lalu di panggil ke control pengguna!!!!!!!
					$this->session->set_userdata($data);
					
				
				// 	if($pengguna_toko['role_id']== 3) {
						
						redirect('dashboard_toko');
						
					
				// }else{

				// 		echo'salah';
				// 	}
					


				}else{
					$this->session->set_flashdata('pesan_sandi','<p class="font-weight-light text-danger">Sandi Salah!!!!!!!!!</p>');
					redirect('toko_login');
				}

			}else{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger" role="alert">akun ini belum di aktivasi!</div>');
				redirect('toko_login');
			}
		}else {
			$this->session->set_flashdata('pesan','<div class="alert alert-danger" role="alert">username tidak ditemukan!</div>');
			redirect('toko_login');
		}


	}


	public function daftar()
	{
		$this->form_validation->set_rules('username','Username', 'required|trim|is_unique[pengguna_toko.username]',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('nama','Nama', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		// $this->form_validation->set_rules('no_tlpn','No_tlpn', 'required|trim',[
		// 	'required' => 'wajib diisi!'
		// ]);
		$this->form_validation->set_rules('nama_toko','Nama_toko', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('alamat','Alamat', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('ttg_prsh','Ttg_prsh', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('sandi1','Sandi', 'required|trim|min_length[3]|matches[sandi2]',[
			'matches'=> 'sandi tidak sama!',
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('sandi2','Sandi', 'required|trim|matches[sandi1]');
		
		$this->form_validation->set_rules('email','Email', 'required|trim|valid_email',[
			'required' => 'wajib diisi!',
			'valid_email' => 'email tidak valid!'
		]);

		
		$this->form_validation->set_rules('no_tlpn','No_tlpn', 'required|trim|min_length[12]',[
			'required' => 'wajib diisi!',
			'min_length'=>'minimal 12 angka!'
		]);

		if($this->form_validation->run() == false)
		{

			$data['title'] = 'daftar';
			$this->load->view('templates/auth_header',$data);
			$this->load->view('toko/daftar-toko');
			$this->load->view('templates/auth_footer');
		} else{
			$data =[
				'username' => htmlspecialchars ($this->input->post('username', true)),
				'nama' => htmlspecialchars ($this->input->post('nama', true)),
				'nama_toko' => htmlspecialchars ($this->input->post('nama_toko', true)),
				'alamat' => htmlspecialchars ($this->input->post('alamat', true)),
				'ttg_prsh' => htmlspecialchars ($this->input->post('ttg_prsh', true)),
				'aktivasi' => 1,
				'role_id' => 3,
				'waktu_daftar' => time(),
				'sandi' => password_hash($this->input->post('sandi1'),PASSWORD_DEFAULT),
				'image' =>'default.jpg',
				'email' => htmlspecialchars ($this->input->post('email', true)),
				'no_tlpn' => htmlspecialchars ($this->input->post('no_tlpn', true)),


			];
			// memasukan data input ke dalam database
			$this->db->insert('pengguna_toko',$data);

			// menampilkan pesan eror di panggil di view
			$this->session->set_flashdata('pesan','<div class="alert alert-warning" role="alert">Selamat akun anda sudah terdaftar, silakan login!</div>');
			redirect('toko_login');

		}

	}


	public function keluar()
	{
		// unset_userdata untuk menghapus data email+role_id yang ada di function_login!!!!!!
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role_id');

		$this->session->set_flashdata('pesan','<div class="alert alert-warning" role="alert">Berhasil Logout</div>');
		redirect('toko_login');
	}
}

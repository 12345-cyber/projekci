<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}
	public function index()
	{
		$this->form_validation->set_rules('email','Email','trim|required|valid_email',[
			'required' => 'tidak ditemukan!',
			'valid_email' => 'email tidak valid!'
		]);
		$this->form_validation->set_rules('sandi','Sandi','trim|required',[
			'required' => 'sandi salah!'
		]);
		if($this->form_validation->run()== false){


			$data['title'] = 'login';
			$this->load->view('templates/auth_header',$data);
			$this->load->view('auth/login');
			$this->load->view('templates/auth_footer');
		} else {
			// $this->_login(); untuk menambah kan function 
			$this->_login();
		}
	}


	private function _login()
	{
		$email =$this->input->post('email');
		$sandi =$this->input->post('sandi');



		$pengguna = $this->db->get_where('pengguna',['email'=> $email])->row_array();
		
		// jika penggunanya ada
		if($pengguna) {
			// jika penggunanya aktif
			if ($pengguna['aktivasi']==1){
				// cek sandi
				if(password_verify($sandi, $pengguna['sandi'])) {
					$data = [
						'email' =>$pengguna['email'],
						'role_id' => $pengguna['role_id']
					];

					// set_userdata untuk menyimpan data email+role_id lalu di panggil ke control pengguna!!!!!!!
					$this->session->set_userdata($data);
					
				
					if($pengguna['role_id']== 1) {
						
						redirect('admin');
						
					
				}else{

						redirect('pengguna');
					}
					


				}else{
					$this->session->set_flashdata('pesan_sandi','<p class="font-weight-light text-danger">Sandi Salah!!!!!!!!!</p>');
					redirect('auth');
				}

			}else{
				$this->session->set_flashdata('pesan','<div class="alert alert-danger" role="alert">akun ini belum di aktivasi!</div>');
				redirect('auth');
			}
		}else {
			$this->session->set_flashdata('pesan','<div class="alert alert-danger" role="alert">username tidak ditemukan!</div>');
			redirect('auth');
		}


	}


	public function daftar()
	{
		$this->form_validation->set_rules('nama','Nama', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('email','Email', 'required|trim|valid_email|is_unique[pengguna.email]',[
			'required' => 'wajib diisi!',
			'valid_email' => 'email tidak valid!',
			'is_unique' => 'email sudah terdaftar!'
		]);
		// $this->form_validation->set_rules('no_tlpn','No_tlpn', 'required|trim',[
		// 	'required' => 'wajib diisi!'
		// ]);
		$this->form_validation->set_rules('no_tlpn','No_tlpn', 'required|trim|min_length[12]',[
			'required' => 'wajib diisi!',
			'min_length'=>'minimal 12 angka!'
		]);
		$this->form_validation->set_rules('alamat','Alamat', 'required|trim',[
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('sandi1','Sandi', 'required|trim|min_length[3]|matches[sandi2]',[
			'matches'=> 'sandi tidak sama!',
			'required' => 'wajib diisi!'
		]);
		$this->form_validation->set_rules('sandi2','Sandi', 'required|trim|matches[sandi1]');

		if($this->form_validation->run() == false)
		{

			$data['title'] = 'daftar';
			$this->load->view('templates/auth_header',$data);
			$this->load->view('auth/daftar');
			$this->load->view('templates/auth_footer');
		} else{
			$data =[
				'nama' => htmlspecialchars ($this->input->post('nama', true)),
				'email' => htmlspecialchars ($this->input->post('email', true)),
				'image' =>'default.jpg',
				'no_tlpn' => htmlspecialchars ($this->input->post('no_tlpn', true)),
				'alamat' => htmlspecialchars ($this->input->post('alamat', true)),
				'sandi' => password_hash($this->input->post('sandi1'),PASSWORD_DEFAULT),
				'role_id' => 2,
				'aktivasi' => 1,
				'waktu_daftar' => time()


			];
			// memasukan data input ke dalam database
			$this->db->insert('pengguna',$data);

			// menampilkan pesan eror di panggil di view
			$this->session->set_flashdata('pesan','<div class="alert alert-warning" role="alert">Selamat akun anda sudah terdaftar, silakan login!</div>');
			redirect('auth');

		}

	}


	public function keluar()
	{
		// unset_userdata untuk menghapus data email+role_id yang ada di function_login!!!!!!
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id');

		$this->session->set_flashdata('pesan','<div class="alert alert-warning" role="alert">Berhasil Logout</div>');
		redirect('auth');
	}
}


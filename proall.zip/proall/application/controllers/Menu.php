<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {
    
    public function index()
    {
        $data['title'] = 'Menu Manajemen';
        // get_where memanggil data yangada di dalam datbase dan menyamakan data di set_userdata yang ada di control auth  
        $data['pengguna'] = $this->db->get_where('pengguna',['email' => $this->session->userdata('email')])->row_array();

        // query untu file menu/index
        // kalau data yang di ambil cuman sebaris bisa pakai row_array, kalau banyak result_array
        $data['menu'] = $this->db->get('pengguna_menu')->result_array();

        // ini roles form_validation
        $this->form_validation->set_rules('menu', 'Menu', 'required',[
            'required' => 'tidak berhasil ditambahkan'
        ]);

        // form_validation yang di tangkap di index menu 
        if($this->form_validation->run()== false){

            $this->load->view('templates/header',$data);
            $this->load->view('templates/sidebar',$data);
            $this->load->view('templates/topbar',$data);
            $this->load->view('menu/index',$data);
            $this->load->view('templates/footer');
        }else{
            $this->db->insert('pengguna_menu', ['menu'=> $this->input->post('menu')]);
            $this->session->set_flashdata('pesan','<div class="alert alert-warning" role="alert">Data berhasil ditambahkan</div>');
			redirect('menu');
        }
       
        
    }

    public function submenu()
    {
        $data['title'] = 'Sub Menu Manajemen';
        // get_where memanggil data yangada di dalam datbase dan menyamakan data di set_userdata yang ada di control auth  
        $data['pengguna'] = $this->db->get_where('pengguna',['email' => $this->session->userdata('email')])->row_array();

        // untuk memanggil alias
        $this->load->model('Menu_model','menu');
        // memangil model   
        $data['subMenu'] = $this->menu->getSubMenu(); 
         


        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('menu/submenu',$data);
        $this->load->view('templates/footer');
    }

    
}
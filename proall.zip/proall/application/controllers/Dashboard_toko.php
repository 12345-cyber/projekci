<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_toko extends CI_Controller {
    
    public function index()
    {
        $data['title'] = 'utama';
        // get_where memanggil data yangada di dalam datbase dan menyamakan data di set_userdata yang ada di control auth  
        $data['pengguna_toko'] = $this->db->get_where('pengguna_toko',['username' => $this->session->userdata('username')])->row_array();
        
       
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        // $this->load->view('templates/topbar');
        $this->load->view('toko/index',$data);
        // $this->load->view('templates/footer');
        
    }

 
}





    
        <!-- Begin Page Content -->
        <div class="container-fluid">

        <h1 class="h3 mb-4 text-gray-800">Profile saya</h1>
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="<?= base_url('assets/img/profile/') . $pengguna['image'] ;?>" class="card-img" >
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?= $pengguna['nama']?></h5>
        <p class="card-text"><?= $pengguna['email']?></p>
        <p class="card-text"><?= $pengguna['no_tlpn']?></p>
        <p class="card-text"><?= $pengguna['alamat']?></p>
        <p class="card-text"><small class="text-muted">daftar <?= date('d F Y', $pengguna['waktu_daftar']);?></small></p>
      </div>
    </div>
  </div>
</div>

          <!-- Page Heading -->
          <!-- <h1 class="h3 mb-4 text-gray-800">Menu</h1>
          <div class="card-deck">
  <div class="card">
    <img src="....." class="card-img-top" >
    <div class="card-body">
      <h5 class="card-title"><?= $menu ['nama']?></h5>
      <p class="card-text"><?= $menu ['ket']?></p>
      <p class="card-text"><?= $menu ['harga']?></p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div> -->
  <!-- <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div>
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 3 mins ago</small>
    </div>
  </div>
</div> -->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      